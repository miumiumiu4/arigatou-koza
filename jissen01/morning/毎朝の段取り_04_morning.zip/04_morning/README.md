# 毎朝の段取り（MUSE実践編 第1回 ④）

コマンド1つで、「予定」「メール」「受注」の3つの部品がデータを読み、「まずこれ（3つ）」と今日の時間割が入った段取りレポートを、日付ごとのファイルに書きます。Python の標準ライブラリだけで動きます（追加のインストールは要りません）。送信・投稿・お金の操作はしません。

## 動かし方（架空データで試す）
Mac：
```
cd 04_morning
python3 dandori.py 2026-11-09
```
Windows（PowerShell）：
```
cd 04_morning
py dandori.py 2026-11-09
```
→ `reports/2026-11-09_段取り.md` ができます。日付を省くと今日の分を作ります。テストは `python3 -m unittest discover tests`（Windows は `py -m unittest discover tests`）。

## 自分のデータに差し替える口
`config.json` の部品ごとに、`source` を選びます。
- `dummy`：`dummy/予定.csv`・`dummy/メール.csv`・`dummy/受注.csv`（架空。日付は「今日から何日目か」の数字）
- `csv_export`：自分のシステムやメールソフトが書き出した CSV。`path` にファイルの場所、`columns` に列名の対応（{"こちらの列名": "相手の列名"}）を書きます。手で書く人は、dummy の表を写して自分の分を書いてください（列名はそのまま）
- `not_connected`：まだつないでいない
使わない部品は `"on": false`。仕事の時間と集荷の時刻は `start`・`end`・`pickup`。

こちらの列名：
- 予定：日付,時刻,所要分,内容
- メール：受信日,差出人,件名,本文,返信済み
- 受注：受注日,注文番号,商品,数量,出荷予定日,状態（新規／登録済み／出荷済み）

## データの扱い
自分のデータとレポートは `exports/`・`reports/` に置き、GitHub などには上げないでください（.gitignore 済み）。
