"""毎朝の段取り：各部品がデータを読み、段取り役が1枚の時間割にまとめる。

たとえ話：朝礼の前に、各係（予定・メール・受注…）がメモを持ってくる。段取り役は、動かせない予定＝大きな石を
先に置き、隙間に「急ぎ → 今日 → 余裕があれば」の順で小石（返信・登録・梱包…）を詰める。

使い方：python3 dandori.py [日付]     （日付を省くと今日）
  読むもの：config.json（部品の ON/OFF とデータの読み先）
  書くもの：reports/<日付>_段取り.md（同じ日はうわがき）
送信・投稿・お金の操作はしない。動かなかった部品は、場所と理由をレポートに残して、ほかの部品は続ける。
Python の標準ライブラリだけで動く。
"""
import datetime as dt
import json
import sys
from pathlib import Path

from parts import juchu, mail, yotei
from parts.common import URGENCY

HERE = Path(__file__).resolve().parent
PARTS = {"予定": yotei, "メール": mail, "受注": juchu}   # 今日つくる部品
LATER = ["送り状", "在庫", "SNS", "労務", "会計"]          # 補講でつなぐ部品（今は名前だけ）


def hm(s):
    h, m = map(int, s.split(":"))
    return h * 60 + m


def hhmm(n):
    return f"{n // 60:02d}:{n % 60:02d}"


def collect(today, config):
    stones, sections, problems, off = [], [], [], []
    for name, conf in config["parts"].items():
        if not conf.get("on"):
            off.append(name)
            continue
        if name not in PARTS:
            problems.append(f"部品「{name}」：まだ作っていません（補講でつなぎます）")
            continue
        try:
            res = PARTS[name].run(today, {**conf, "pickup": config.get("pickup", "15:00")})
        except Exception as e:  # 1つの部品が止まっても、ほかは続ける
            problems.append(f"部品「{name}」（parts/{PARTS[name].__name__.split('.')[-1]}.py・source={conf.get('source')}）：{type(e).__name__}：{e}")
            continue
        if res is None:
            off.append(f"{name}（つないでいない）")
            continue
        stones += res["stones"]
        sections.append((name, res["section"]))
    return stones, sections, problems, off


def schedule(stones, config):
    start, end, pickup = hm(config["start"]), hm(config["end"]), hm(config.get("pickup", config["end"]))
    big = sorted(({**s, "s": hm(s["time"]), "e": hm(s["time"]) + s["minutes"]} for s in stones if s["time"]), key=lambda s: s["s"])
    small = sorted((s for s in stones if not s["time"]), key=lambda s: (URGENCY[s["urgency"]], s["kind"] != "発送", s["minutes"]))
    placed, over, warn, cur = [], [], [], start
    for s in small:
        t = cur
        for b in big:
            if t < b["e"] and t + s["minutes"] > b["s"]:
                t = max(t, b["e"])
        if t + s["minutes"] > end:
            over.append(s)
            continue
        placed.append({**s, "s": t, "e": t + s["minutes"]})
        if s["kind"] == "発送" and t + s["minutes"] > pickup:
            warn.append(f"「{s['title']}」が集荷（{config['pickup']}）に間に合いません")
        cur = t + s["minutes"]
    return sorted(placed + big, key=lambda x: x["s"]), [p for p in placed], over, warn


def report(today, config, stones, sections, problems, off):
    timeline, placed, over, warn = schedule(stones, config)
    busy = sum(x["e"] - x["s"] for x in timeline)
    first = placed[:3]
    L = [f"# {today:%Y-%m-%d} の段取り", ""]
    L.append("## まずこれ（3つ）")
    L += [f"{i}. 【{s['urgency']}】{s['title']}（{s['minutes']}分）{'― ' + s['why'] if s['why'] else ''}" for i, s in enumerate(first, 1)] or ["- 急ぎのものはありません"]
    if warn or problems or over:
        L += ["", "## ⚠ 気をつけること"]
        L += [f"- {w}" for w in warn] + [f"- {p}" for p in problems]
        if over:
            L.append(f"- 今日の時間（{config['start']}〜{config['end']}）に入りきらないものが{len(over)}件あります（下の「入りきらないもの」）")
    L += ["", f"## 時間割（埋まっている時間 {busy // 60}時間{busy % 60}分）", "", "| 時間 | やること | 種類 | 急ぎ度 |", "|---|---|---|---|"]
    L += [f"| {hhmm(x['s'])}〜{hhmm(x['e'])} | {x['title']} | {x['kind']} | {'予定' if x['time'] else x['urgency']} |" for x in timeline]
    for name, lines in sections:
        L += ["", f"## {name}", ""] + lines
    if over:
        L += ["", "## 入りきらないもの（明日へ回すか、人に頼む）", ""] + [f"- {s['title']}（{s['minutes']}分）" for s in over]
    L += ["", "---", f"部品：使った {'・'.join(n for n, _ in sections) or 'なし'}／止めている {'・'.join(off) or 'なし'}／補講でつなぐ {'・'.join(LATER)}", ""]
    return "\n".join(L), {"placed": placed, "over": over, "warn": warn, "busy": busy, "timeline": timeline}


def main(argv):
    today = dt.date.fromisoformat(argv[1]) if len(argv) > 1 else dt.date.today()
    config = json.loads((HERE / "config.json").read_text(encoding="utf-8"))
    stones, sections, problems, off = collect(today, config)
    text, info = report(today, config, stones, sections, problems, off)
    out = HERE / "reports" / f"{today:%Y-%m-%d}_段取り.md"
    out.parent.mkdir(exist_ok=True)
    out.write_text(text, encoding="utf-8")
    print(f"できました：{out}（やること{len(info['placed'])}件・入りきらない{len(info['over'])}件・動かなかった部品{len(problems)}件）")


if __name__ == "__main__":
    main(sys.argv)
