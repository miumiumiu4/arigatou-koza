"""部品の共通の道具：データの読み方（source の差し替え口）と、やること（石）の形。

source は3つから選ぶ（config.json の部品ごと）：
  dummy         … dummy/<部品>.csv（日付は「今日から何日目か」の数字。0＝今日、-1＝昨日）
  csv_export    … 自分のシステムが書き出した CSV（path）と、列名の対応表（columns：{"こちらの列名": "相手の列名"}）
  not_connected … まだつないでいない（何も読まない）
"""
import csv
import datetime as dt
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
URGENCY = {"急ぎ": 1, "今日": 2, "余裕があれば": 3}


def stone(kind, title, urgency, minutes, why="", time=None):
    """やること1つ。time があれば動かせない予定（大きな石）、なければ隙間に詰める小石"""
    return {"kind": kind, "title": title, "urgency": urgency, "minutes": int(minutes), "why": why, "time": time}


def day(today, offset_or_date):
    """'0'・'-1' のような相対の日付も、'2026-11-09' のような日付も、日付に直す"""
    s = str(offset_or_date).strip()
    if s.lstrip("-").isdigit():
        return today + dt.timedelta(days=int(s))
    return dt.date.fromisoformat(s.replace("/", "-"))


def read_rows(name, conf):
    """部品のデータを、こちらの列名の dict の並びで返す"""
    src = conf.get("source", "not_connected")
    if src == "not_connected":
        return None
    if src == "dummy":
        path = HERE / "dummy" / f"{name}.csv"
        cols = {}
    elif src == "csv_export":
        path = Path(conf["path"]).expanduser()
        cols = conf.get("columns", {})
    else:
        raise ValueError(f"source「{src}」は使えません（dummy／csv_export／not_connected）")
    if not path.exists():
        raise FileNotFoundError(f"{path} がありません")
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    if cols:
        missing = [theirs for theirs in cols.values() if rows and theirs not in rows[0]]
        if missing:
            raise KeyError(f"{path.name} に列「{'」「'.join(missing)}」がありません（列名の対応表を確かめてください）")
        rows = [{ours: r.get(theirs, "") for ours, theirs in cols.items()} for r in rows]
    return rows
