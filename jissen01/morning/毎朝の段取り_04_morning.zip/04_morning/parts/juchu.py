"""受注：今日出荷するもの（急ぎ）と、登録を待っている新しい注文（今日）。列：受注日,注文番号,商品,数量,出荷予定日,状態
結果（今日出荷する注文）は、ほかの部品（送り状・在庫）が使えるように shared に入れる"""
from .common import day, read_rows, stone

NAME = "受注"


def run(today, conf):
    rows = read_rows(NAME, conf)
    if rows is None:
        return None
    ship = [r for r in rows if r.get("状態") != "出荷済み" and r.get("出荷予定日") and day(today, r["出荷予定日"]) <= today]
    new = [r for r in rows if r.get("状態") == "新規"]
    stones, lines = [], []
    if ship:
        n = len(ship)
        stones.append(stone("発送", f"今日の出荷 {n}件の梱包・出荷", "急ぎ", conf.get("minutes_per_ship", 10) * n, f"集荷（{conf.get('pickup', '15:00')}）までに出す"))
        lines.append(f"**今日の出荷（{n}件）**")
        lines += [f"- {r['注文番号']}　{r['商品']} × {r['数量']}" + ("（出荷予定日を過ぎています）" if day(today, r["出荷予定日"]) < today else "") for r in ship]
    if new:
        stones.append(stone("受注", f"新しい注文 {len(new)}件の登録と受け付けの連絡", "今日", conf.get("minutes_per_new", 5) * len(new), "注文は当日中に受け付けの連絡"))
        if lines:
            lines.append("")
        lines.append(f"**登録待ちの新しい注文（{len(new)}件）**")
        lines += [f"- {r['注文番号']}　{r['商品']} × {r['数量']}" for r in new]
    return {"stones": stones, "section": lines or ["- 今日の出荷・新しい注文はありません"], "shared": {"ship": ship}}
