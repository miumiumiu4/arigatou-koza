"""メール：返信が要るものの一覧と、返信の下書き（送らない）。列：受信日,差出人,件名,本文,返信済み"""
from .common import day, read_rows, stone

NAME = "メール"
DRAFT = "{who}様\n\nご連絡ありがとうございます。「{subject}」の件、承知しました。\n内容を確認し、{when}にあらためてご連絡いたします。\n"


def run(today, conf):
    rows = read_rows(NAME, conf)
    if rows is None:
        return None
    todo = [r for r in rows if r.get("返信済み", "").strip() not in ("済", "済み", "はい", "1", "yes")]
    stones, lines = [], []
    for r in sorted(todo, key=lambda r: day(today, r["受信日"])):
        got = day(today, r["受信日"])
        late = (today - got).days
        urg = "急ぎ" if late >= 1 else "今日"
        why = f"受け取ってから{late}日たっています" if late >= 1 else "今日届いたもの"
        stones.append(stone("返信", f"{r['差出人']}「{r['件名']}」に返信", urg, conf.get("minutes", 10), why))
        lines.append(f"### {r['差出人']}「{r['件名']}」（{got:%m/%d} 受信・{urg}）")
        lines.append("```")
        lines.append(DRAFT.format(who=r["差出人"], subject=r["件名"], when="本日中" if urg == "急ぎ" else "明日まで").rstrip())
        lines.append("```")
    return {"stones": stones, "section": lines or ["- 返信が要るメールはありません"]}
