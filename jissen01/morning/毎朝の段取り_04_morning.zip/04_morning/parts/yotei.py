"""予定：その日の決まった予定（大きな石）。列：日付,時刻,所要分,内容"""
from .common import day, read_rows, stone

NAME = "予定"


def run(today, conf):
    rows = read_rows(NAME, conf)
    if rows is None:
        return None
    stones = [stone("予定", r["内容"], "今日", r.get("所要分") or 60, time=r["時刻"])
              for r in rows if day(today, r["日付"]) == today and r.get("時刻")]
    lines = [f"- {s['time']}〜（{s['minutes']}分）{s['title']}" for s in sorted(stones, key=lambda s: s["time"])]
    return {"stones": stones, "section": lines or ["- 今日の予定はありません"]}
