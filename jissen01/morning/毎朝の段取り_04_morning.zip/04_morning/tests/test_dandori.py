"""架空のデータで確かめる：python3 -m unittest discover tests"""
import datetime as dt
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(HERE))
import dandori  # noqa: E402

DAY = dt.date(2026, 11, 9)
CONFIG = json.loads((HERE / "config.json").read_text(encoding="utf-8"))


def run(config=CONFIG, day=DAY):
    stones, sections, problems, off = dandori.collect(day, config)
    text, info = dandori.report(day, config, stones, sections, problems, off)
    return text, info, problems


class TestDandori(unittest.TestCase):
    def test_today_only(self):
        text, info, problems = run()
        self.assertEqual(problems, [])
        self.assertNotIn("明日の現場", text)                     # 明日の予定は入れない
        self.assertNotIn("請求書の件", text)                     # 返信済みは入れない
        self.assertEqual(len(info["placed"]), 5)

    def test_order_and_first_three(self):
        text, info, _ = run()
        self.assertEqual([s["urgency"] for s in info["placed"]], ["急ぎ", "急ぎ", "今日", "今日", "今日"])
        self.assertEqual(info["placed"][0]["title"], "今日の出荷 2件の梱包・出荷")  # 出荷予定日を過ぎた分も今日へ
        self.assertEqual(info["placed"][0]["minutes"], 20)
        self.assertIn("1. 【急ぎ】今日の出荷 2件", text)
        self.assertIn("2. 【急ぎ】テスト工務店「見積もりのお願い」に返信", text)

    def test_no_overlap_with_fixed(self):
        _, info, _ = run()
        t = info["timeline"]
        for a, b in zip(t, t[1:]):
            self.assertLessEqual(a["e"], b["s"], f"{a['title']} と {b['title']} が重なる")
        self.assertEqual(info["busy"], 240)

    def test_relative_dates_follow_the_day(self):
        _, info, _ = run(day=DAY + dt.timedelta(days=30))     # 何日に動かしても「今日」のデータになる
        self.assertEqual(len(info["placed"]), 5)

    def test_broken_part_does_not_stop_others(self):
        conf = json.loads(json.dumps(CONFIG))
        conf["parts"]["メール"] = {"on": True, "source": "csv_export", "path": "/nowhere/mail.csv"}
        text, info, problems = run(conf)
        self.assertEqual(len(problems), 1)
        self.assertIn("部品「メール」（parts/mail.py・source=csv_export）", problems[0])
        self.assertIn("今日の出荷 2件", text)                    # 受注は続けて動く

    def test_csv_export_with_column_map(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "orders.csv"
            p.write_text("order_id,item,qty,ship_date,status,ordered\nA-1,テスト商品,4,2026-11-09,登録済み,2026-11-08\n", encoding="utf-8")
            conf = json.loads(json.dumps(CONFIG))
            conf["parts"]["受注"] = {"on": True, "source": "csv_export", "path": str(p),
                                   "columns": {"注文番号": "order_id", "商品": "item", "数量": "qty", "出荷予定日": "ship_date", "状態": "status", "受注日": "ordered"}}
            text, info, problems = run(conf)
            self.assertEqual(problems, [])
            self.assertIn("A-1　テスト商品 × 4", text)
            conf["parts"]["受注"]["columns"]["数量"] = "quantity"
            _, _, problems = run(conf)
            self.assertIn("列「quantity」がありません", problems[0])

    def test_over_and_pickup_warning(self):
        conf = json.loads(json.dumps(CONFIG))
        conf["start"], conf["end"], conf["pickup"] = "09:00", "09:25", "09:05"
        text, info, _ = run(conf)
        self.assertEqual(len(info["over"]), 4)                  # 出荷20分のあと、残り5分に10分の返信は入らない
        self.assertIn("「今日の出荷 2件の梱包・出荷」が集荷（09:05）に間に合いません", info["warn"])
        self.assertIn("入りきらないもの", text)

    def test_parts_off(self):
        conf = json.loads(json.dumps(CONFIG))
        conf["parts"]["メール"]["on"] = False
        text, info, problems = run(conf)
        self.assertEqual(len(info["placed"]), 2)
        self.assertIn("止めている メール", text)


if __name__ == "__main__":
    unittest.main()
